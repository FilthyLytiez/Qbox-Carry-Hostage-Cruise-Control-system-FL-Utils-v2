local config = require 'config'

local carry = {
    inProgress = false,
    targetSrc = -1,
    type = "",
    animThread = nil
}

local hostage = {
    inProgress = false,
    targetSrc = -1,
    lastHostageTime = 0,
    monitorThread = nil
}

local cruiseControl = {
    enabled = false,
    autoThread = nil
}

local function showNotification(message, type, title)
    lib.notify({
        title = title or 'FL Utils',
        description = message,
        type = type or 'inform',
        position = config.notifications.position,
        duration = config.notifications.duration,
    })
end

local function loadAnimDict(dict)
    if not dict or dict == "" then return false end
    
    while not HasAnimDictLoaded(dict) do
        RequestAnimDict(dict)
        Wait(10)
    end
    
    return true
end

local function getClosestPlayer(radius)
    local players = GetActivePlayers()
    local closestDistance = -1
    local closestPlayer = -1
    local playerPed = cache.ped
    local playerCoords = GetEntityCoords(playerPed)

    for _, playerId in ipairs(players) do
        local targetPed = GetPlayerPed(playerId)
        if targetPed ~= playerPed then
            local targetCoords = GetEntityCoords(targetPed)
            local distance = #(targetCoords - playerCoords)
            if closestDistance == -1 or closestDistance > distance then
                closestPlayer = playerId
                closestDistance = distance
            end
        end
    end
    
    if closestDistance ~= -1 and closestDistance <= radius then
        return closestPlayer
    else
        return nil
    end
end

local function startCarryAnimation()
    if carry.animThread then return end
    
    carry.animThread = CreateThread(function()
        while carry.inProgress do
            local ped = cache.ped
            
            if carry.type == "beingcarried" then
                if not IsEntityPlayingAnim(ped, config.carry.animations.carried.dict, config.carry.animations.carried.anim, 3) then
                    TaskPlayAnim(ped, 
                        config.carry.animations.carried.dict, 
                        config.carry.animations.carried.anim, 
                        8.0, -8.0, 100000, 
                        config.carry.animations.carried.flag, 
                        0, false, false, false)
                end
            elseif carry.type == "carrying" then
                if not IsEntityPlayingAnim(ped, config.carry.animations.carrier.dict, config.carry.animations.carrier.anim, 3) then
                    TaskPlayAnim(ped, 
                        config.carry.animations.carrier.dict, 
                        config.carry.animations.carrier.anim, 
                        8.0, -8.0, 100000, 
                        config.carry.animations.carrier.flag, 
                        0, false, false, false)
                end
            end
            
            Wait(100) 
        end
        carry.animThread = nil
    end)
end

local function stopCarry()
    carry.inProgress = false
    ClearPedSecondaryTask(cache.ped)
    DetachEntity(cache.ped, true, false)
    TriggerServerEvent("fl_utils:carryStop", carry.targetSrc)
    carry.targetSrc = -1
    carry.type = ""
    
    if carry.animThread then
        carry.animThread = nil
    end
    
    showNotification(config.notifications.carryStopped, "inform")
end

local function startCarry()
    if not config.carry.enabled then return end
    
    if not carry.inProgress then
        local closestPlayer = getClosestPlayer(config.carry.interactionDistance)
        if closestPlayer then
            local targetSrc = GetPlayerServerId(closestPlayer)
            if targetSrc ~= -1 then
                carry.inProgress = true
                carry.targetSrc = targetSrc
                carry.type = "carrying"
                
                TriggerServerEvent("fl_utils:carrySync", targetSrc)
                loadAnimDict(config.carry.animations.carrier.dict)
                
                showNotification(config.notifications.carryStarted, "success")
                startCarryAnimation()
            else
                showNotification(config.notifications.carryNoTarget, "error")
            end
        else
            showNotification(config.notifications.carryNoTarget, "error")
        end
    else
        stopCarry()
    end
end

local function toggleCruiseControl(speed)
    local ped = cache.ped
    local vehicle = GetVehiclePedIsIn(ped, false)
    
    if not IsPedInAnyVehicle(ped, false) then return end
    if GetPedInVehicleSeat(vehicle, -1) ~= ped then return end
    
    if cruiseControl.enabled then
        SetEntityMaxSpeed(vehicle, config.cruiseControl.maxSpeed)
        cruiseControl.enabled = false
        showNotification(config.notifications.cruiseDisabled, 'inform')
        return
    end
    
    if speed then
        SetEntityMaxSpeed(vehicle, speed)
        cruiseControl.enabled = true
        showNotification(string.format(config.notifications.cruiseEnabled, math.floor(speed * 3.6)), 'success')
    end
end

local function startCruiseControlMonitor()
    if cruiseControl.autoThread then return end
    
    cruiseControl.autoThread = CreateThread(function()
        while config.cruiseControl.enabled do
            local ped = cache.ped
            
            if IsPedInAnyVehicle(ped, false) and not cruiseControl.enabled then
                local vehicle = GetVehiclePedIsIn(ped, false)
                
                if GetPedInVehicleSeat(vehicle, -1) == ped then
                    local speed = GetEntitySpeed(vehicle)
                    
                    if math.floor(speed * 3.6) == config.cruiseControl.speedSet then
                        SetEntityMaxSpeed(vehicle, speed)
                        cruiseControl.enabled = true
                        showNotification(string.format(config.notifications.cruiseEnabled, config.cruiseControl.speedSet), 'success')
                    end
                end
                
                Wait(config.cruiseControl.checkInterval)
            else
                Wait(1000)
            end
        end
        cruiseControl.autoThread = nil
    end)
end

local function startHostageMonitor()
    if hostage.monitorThread then return end
    
    hostage.monitorThread = CreateThread(function()
        while hostage.inProgress do
            local ped = cache.ped
            
            if IsEntityDead(ped) then
                hostage.inProgress = false
                TriggerServerEvent("fl_utils:hostageStop", hostage.targetSrc, NetworkGetNetworkIdFromEntity(ped))
                showNotification(config.notifications.hostageDied, "error")
                break
            end
            
            local targetPed = GetPlayerPed(GetPlayerFromServerId(hostage.targetSrc))
            if not DoesEntityExist(targetPed) or #(GetEntityCoords(ped) - GetEntityCoords(targetPed)) > config.hostage.maxDistance then
                hostage.inProgress = false
                TriggerServerEvent("fl_utils:hostageStop", hostage.targetSrc, NetworkGetNetworkIdFromEntity(ped))
                ClearPedTasks(ped)
                showNotification(config.notifications.hostageTooFar, "error")
                break
            end
            
            if IsControlJustPressed(0, config.controlCodes[config.hostage.controls.release] or 38) then
                releaseHostage()
                break
            end
            
            if IsControlJustPressed(0, config.controlCodes[config.hostage.controls.kill] or 303) then
                killHostage()
                break
            end
            
            Wait(50) 
        end
        hostage.monitorThread = nil
    end)
end

local function releaseHostage()
    hostage.inProgress = false
    TriggerServerEvent("fl_utils:hostageStop", hostage.targetSrc, NetworkGetNetworkIdFromEntity(cache.ped))
    ClearPedTasks(cache.ped)
    hostage.targetSrc = -1
    
    if hostage.monitorThread then
        hostage.monitorThread = nil
    end
    
    showNotification(config.notifications.hostageReleased, "inform")
end

local function killHostage()
    hostage.inProgress = false
    TriggerServerEvent("fl_utils:hostageKill", hostage.targetSrc, NetworkGetNetworkIdFromEntity(cache.ped))
    ClearPedTasks(cache.ped)
    hostage.targetSrc = -1
    
    if hostage.monitorThread then
        hostage.monitorThread = nil
    end
    
    showNotification(config.notifications.hostageKilled, "error")
end

local function takeHostage()
    if not config.hostage.enabled then return end
    
    local currentTime = GetGameTimer()
    if (currentTime - hostage.lastHostageTime) < (config.hostage.cooldown * 1000) then
        showNotification(config.notifications.hostageCooldown, "error")
        return
    end
    
    if hostage.inProgress then
        releaseHostage()
        return
    end
    
    local closestPlayer = getClosestPlayer(config.hostage.interactionDistance)
    if not closestPlayer then
        showNotification(config.notifications.hostageNoTarget, "error")
        return
    end
    
    local targetPed = GetPlayerPed(closestPlayer)
    local targetSrc = GetPlayerServerId(closestPlayer)
    
    if IsEntityDead(targetPed) then
        showNotification(config.notifications.hostageDeadTarget, "error")
        return
    end
    
    if IsPedInAnyVehicle(targetPed, false) then
        showNotification(config.notifications.hostageInVehicle, "error")
        return
    end
    
    local currentWeapon = GetSelectedPedWeapon(cache.ped)
    if currentWeapon == GetHashKey('WEAPON_UNARMED') then
        showNotification(config.notifications.hostageNoWeapon, "error")
        return
    end
    
    local hasValidWeapon = false
    for _, weapon in ipairs(config.hostage.weapons) do
        local weaponHash = GetHashKey(weapon)
        if HasPedGotWeapon(cache.ped, weaponHash, false) and currentWeapon == weaponHash then
            hasValidWeapon = true
            break
        end
    end
    
    if not hasValidWeapon then
        showNotification("You need a suitable weapon to take a hostage", "error")
        return
    end
    
    hostage.inProgress = true
    hostage.targetSrc = targetSrc
    hostage.lastHostageTime = currentTime
    
    loadAnimDict(config.hostage.animations.taker.dict)
    loadAnimDict(config.hostage.animations.victim.dict)
    
    TriggerServerEvent("fl_utils:hostageStart", targetSrc, NetworkGetNetworkIdFromEntity(cache.ped))
    
    showNotification(config.notifications.hostageTaken, "success")
    showNotification(string.format(config.notifications.hostageControls, 
        config.hostage.controls.release, config.hostage.controls.kill), "inform")
    
    startHostageMonitor()
end

local function registerCommands()
    RegisterCommand(config.carry.commandName, startCarry, false)
    RegisterCommand(config.cruiseControl.commandName, function()
        if config.cruiseControl.enabled then
            local ped = cache.ped
            if IsPedInAnyVehicle(ped, false) then
                local vehicle = GetVehiclePedIsIn(ped, false)
                local speed = GetEntitySpeed(vehicle)
                toggleCruiseControl(speed)
            end
        end
    end, false)
    RegisterCommand(config.hostage.commandName, takeHostage, false)
end

local function registerKeybinds()
    RegisterKeyMapping(config.carry.commandName, 'Carry Nearby Player', 'keyboard', config.carry.keyBind)
    RegisterKeyMapping(config.cruiseControl.commandName, 'Toggle Cruise Control', 'keyboard', config.cruiseControl.keyBind)
    RegisterKeyMapping(config.hostage.commandName, 'Take Hostage', 'keyboard', config.hostage.keyBind)
end


CreateThread(function()
    Wait(2000)
    if config.debug then
        print("FL Utils client initialized")
    end
    
    
    registerCommands()
    registerKeybinds()
    
    
    if config.cruiseControl.enabled then
        startCruiseControlMonitor()
    end
end)

RegisterNetEvent("fl_utils:carrySyncTarget", function(targetSrc)
    local targetPed = GetPlayerPed(GetPlayerFromServerId(targetSrc))
    carry.inProgress = true
    carry.type = "beingcarried"
    
    loadAnimDict(config.carry.animations.carried.dict)
    AttachEntityToEntity(cache.ped, targetPed, 0, 
        config.carry.animations.carried.attachX, 
        config.carry.animations.carried.attachY, 
        config.carry.animations.carried.attachZ, 
        0.5, 0.5, 180, false, false, false, false, 2, false)
    
    showNotification(config.notifications.beingCarried, "inform")
    startCarryAnimation()
end)

RegisterNetEvent("fl_utils:carryStop", function()
    stopCarry()
end)

RegisterNetEvent("fl_utils:hostagedByPlayer", function(targetSrc)
    local targetPed = GetPlayerPed(GetPlayerFromServerId(targetSrc))
    
    showNotification(config.notifications.beingHostage, "error")
    
    loadAnimDict(config.hostage.animations.victim.dict)
    TaskPlayAnim(cache.ped, 
        config.hostage.animations.victim.dict, 
        config.hostage.animations.victim.anim, 
        8.0, -8.0, -1, 
        config.hostage.animations.victim.flag, 
        0, false, false, false)
    
    AttachEntityToEntity(cache.ped, targetPed, 0, -0.24, 0.11, 0.0, 0.5, 0.5, 0.0, false, false, false, false, 2, false)
    SetPlayerControl(PlayerId(), false, 1 << 8)
end)

RegisterNetEvent("fl_utils:releasedFromHostage", function()
    DetachEntity(cache.ped, true, false)
    ClearPedTasks(cache.ped)
    SetPlayerControl(PlayerId(), true, 1 << 8)
    showNotification(config.notifications.releasedFromHostage, "success")
end)

RegisterNetEvent("fl_utils:hostageStartTaker", function()
    loadAnimDict(config.hostage.animations.taker.dict)
    TaskPlayAnim(cache.ped, 
        config.hostage.animations.taker.dict, 
        config.hostage.animations.taker.anim, 
        8.0, -8.0, -1, 
        config.hostage.animations.taker.flag, 
        0, false, false, false)
end)

RegisterNetEvent("fl_utils:beKilled", function()
    showNotification(config.notifications.executedByCaptor, "error")
    Wait(500)
    SetEntityHealth(cache.ped, 0)
end)

AddEventHandler('onResourceStop', function(resourceName)
    if resourceName == GetCurrentResourceName() then
        if carry.inProgress then
            stopCarry()
        end
        
        if hostage.inProgress then
            releaseHostage()
        end
        
        if cruiseControl.enabled then
            local ped = cache.ped
            if IsPedInAnyVehicle(ped, false) then
                local vehicle = GetVehiclePedIsIn(ped, false)
                SetEntityMaxSpeed(vehicle, config.cruiseControl.maxSpeed)
            end
        end
        
        if config.debug then
            print("FL Utils client cleaned up")
        end
    end
end)