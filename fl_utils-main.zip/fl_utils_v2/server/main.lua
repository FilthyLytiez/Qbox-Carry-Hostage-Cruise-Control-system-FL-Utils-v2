local config = require 'config'


local carrying = {}
local carried = {}
local hostageData = {}


AddEventHandler('onResourceStart', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    
    local resourceName = "^2FL Utils (" .. GetCurrentResourceName() .. ")"
    print("\n^1----------------------------------------------------------------------------------^7")
    print(resourceName)
    print("^3Filthy Lytiez Server Utilities: Cruise Control, Carry, Hostage^7")
    print("^1----------------------------------------------------------------------------------^7")
    
    if config.debug then
        print("FL Utils server initialized")
    end
end)

RegisterNetEvent("fl_utils:carrySync", function(targetSrc)
    local source = source
    
    if not GetPlayerName(source) or not GetPlayerName(targetSrc) then
        if config.debug then
            print("Invalid player in carry sync: " .. source .. " -> " .. targetSrc)
        end
        return
    end
    
    local sourcePed = GetPlayerPed(source)
    local targetPed = GetPlayerPed(targetSrc)
    
    if not DoesEntityExist(sourcePed) or not DoesEntityExist(targetPed) then
        if config.debug then
            print("Invalid ped entities in carry sync")
        end
        return
    end
    
    local sourceCoords = GetEntityCoords(sourcePed)
    local targetCoords = GetEntityCoords(targetPed)
    
    
    if #(sourceCoords - targetCoords) <= config.carry.interactionDistance then 
        TriggerClientEvent("fl_utils:carrySyncTarget", targetSrc, source)
        carrying[source] = targetSrc
        carried[targetSrc] = source
        
        if config.debug then
            print("Player " .. source .. " is now carrying " .. targetSrc)
        end
    else
        if config.debug then
            print("Players too far apart for carry: " .. #(sourceCoords - targetCoords))
        end
    end
end)

RegisterNetEvent("fl_utils:carryStop", function(targetSrc)
    local source = source

    if carrying[source] then
        TriggerClientEvent("fl_utils:carryStop", targetSrc)
        carried[targetSrc] = nil
        carrying[source] = nil
        
        if config.debug then
            print("Player " .. source .. " stopped carrying " .. targetSrc)
        end
    elseif carried[source] then
        local carrier = carried[source]
        TriggerClientEvent("fl_utils:carryStop", carrier)
        carrying[carrier] = nil
        carried[source] = nil
        
        if config.debug then
            print("Player " .. source .. " was released from being carried by " .. carrier)
        end
    end
end)

RegisterNetEvent("fl_utils:hostageStart", function(targetSrc, playerNetId)
    local source = source
    
    if not GetPlayerName(source) or not GetPlayerName(targetSrc) then
        if config.debug then
            print("Invalid player in hostage start: " .. source .. " -> " .. targetSrc)
        end
        return
    end
    
    if hostageData[source] then
        if config.debug then
            print("Player " .. source .. " is already taking a hostage")
        end
        return
    end
    
    for k, v in pairs(hostageData) do
        if v.victim == targetSrc then
            if config.debug then
                print("Player " .. targetSrc .. " is already a hostage")
            end
            return
        end
    end
    
    local sourcePed = GetPlayerPed(source)
    local targetPed = GetPlayerPed(targetSrc)
    
    if DoesEntityExist(sourcePed) and DoesEntityExist(targetPed) then
        local sourceCoords = GetEntityCoords(sourcePed)
        local targetCoords = GetEntityCoords(targetPed)
        
        if #(sourceCoords - targetCoords) > config.hostage.interactionDistance then
            if config.debug then
                print("Players too far apart for hostage: " .. #(sourceCoords - targetCoords))
            end
            return
        end
    end
    
    hostageData[source] = {
        victim = targetSrc,
        netId = playerNetId,
        startTime = os.time()
    }
    
    TriggerClientEvent("fl_utils:hostagedByPlayer", targetSrc, source)
    TriggerClientEvent("fl_utils:hostageStartTaker", source)
    
    if config.debug then
        print("Player " .. source .. " took " .. targetSrc .. " as hostage")
    end
end)

RegisterNetEvent("fl_utils:hostageStop", function(targetSrc, playerNetId)
    local source = source
    
    if hostageData[source] and hostageData[source].victim == targetSrc then
        TriggerClientEvent("fl_utils:releasedFromHostage", targetSrc)
        hostageData[source] = nil
        
        if config.debug then
            print("Player " .. source .. " released hostage " .. targetSrc)
        end
    end
end)

RegisterNetEvent("fl_utils:hostageKill", function(targetSrc, playerNetId)
    local source = source
    
    if hostageData[source] and hostageData[source].victim == targetSrc then
        TriggerClientEvent("fl_utils:releasedFromHostage", targetSrc)
        TriggerClientEvent("fl_utils:beKilled", targetSrc)
        hostageData[source] = nil
        
        if config.debug then
            print("Player " .. source .. " killed hostage " .. targetSrc)
        end
    end
end)

AddEventHandler('playerDropped', function(reason)
    local source = source
    
    if carrying[source] then
        local carried_player = carrying[source]
        TriggerClientEvent("fl_utils:carryStop", carried_player)
        carried[carried_player] = nil
        carrying[source] = nil
        
        if config.debug then
            print("Player " .. source .. " disconnected while carrying " .. carried_player)
        end
    end

    if carried[source] then
        local carrying_player = carried[source]
        TriggerClientEvent("fl_utils:carryStop", carrying_player)
        carrying[carrying_player] = nil
        carried[source] = nil
        
        if config.debug then
            print("Player " .. source .. " disconnected while being carried by " .. carrying_player)
        end
    end
    
    if hostageData[source] then
        local victim = hostageData[source].victim
        TriggerClientEvent("fl_utils:releasedFromHostage", victim)
        hostageData[source] = nil
        
        if config.debug then
            print("Hostage taker " .. source .. " disconnected, releasing " .. victim)
        end
    end
    
    for k, v in pairs(hostageData) do
        if v.victim == source then
            hostageData[k] = nil
            
            if config.debug then
                print("Hostage victim " .. source .. " disconnected, clearing data for taker " .. k)
            end
            break
        end
    end
end)

function GetCarryingData()
    return {
        carrying = carrying,
        carried = carried
    }
end

function GetHostageData()
    return hostageData
end

function IsPlayerCarrying(playerId)
    return carrying[playerId] ~= nil
end

function IsPlayerCarried(playerId)
    return carried[playerId] ~= nil
end

function IsPlayerTakingHostage(playerId)
    return hostageData[playerId] ~= nil
end

function IsPlayerHostage(playerId)
    for k, v in pairs(hostageData) do
        if v.victim == playerId then
            return true, k 
        end
    end
    return false
end

exports('GetCarryingData', GetCarryingData)
exports('GetHostageData', GetHostageData)
exports('IsPlayerCarrying', IsPlayerCarrying)
exports('IsPlayerCarried', IsPlayerCarried)
exports('IsPlayerTakingHostage', IsPlayerTakingHostage)
exports('IsPlayerHostage', IsPlayerHostage)


local function cleanupStaleData()
    
    for source, target in pairs(carrying) do
        if not GetPlayerName(source) or not GetPlayerName(target) then
            carrying[source] = nil
            carried[target] = nil
            if config.debug then
                print("Cleaned up stale carry data: " .. source .. " -> " .. target)
            end
        end
    end
    
    for source, data in pairs(hostageData) do
        if not GetPlayerName(source) or not GetPlayerName(data.victim) then
            hostageData[source] = nil
            if config.debug then
                print("Cleaned up stale hostage data: " .. source .. " -> " .. data.victim)
            end
        end
    end
end

CreateThread(function()
    while true do
        Wait(300000) 
        cleanupStaleData()
    end
end)

AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    
   
    for source, target in pairs(carrying) do
        TriggerClientEvent("fl_utils:carryStop", target)
        TriggerClientEvent("fl_utils:carryStop", source)
    end
    
    for source, data in pairs(hostageData) do
        TriggerClientEvent("fl_utils:releasedFromHostage", data.victim)
    end
    
    if config.debug then
        print("FL Utils server cleaned up")
    end
end)