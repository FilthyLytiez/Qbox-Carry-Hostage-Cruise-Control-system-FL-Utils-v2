-- ████████╗██╗██╗  ████████╗██╗  ██╗██╗   ██╗    ██╗  ██╗   ██╗████████╗██╗███████╗███████╗
-- ██╔════╝██║██║  ╚══██╔══╝██║  ██║╚██╗ ██╔╝    ██║  ╚██╗ ██╔╝╚══██╔══╝██║██╔════╝╚══███╔╝
-- ██║     ██║██║     ██║   ███████║ ╚████╔╝     ██║   ╚████╔╝    ██║   ██║█████╗    ███╔╝ 
-- ██║     ██║██║     ██║   ██╔══██║  ╚██╔╝      ██║    ╚██╔╝     ██║   ██║██╔══╝   ███╔╝  
-- ██║     ██║███████╗██║   ██║  ██║   ██║       ███████╗██║      ██║   ██║███████╗███████╗
-- ╚═╝     ╚═╝╚══════╝╚═╝   ╚═╝  ╚═╝   ╚═╝       ╚══════╝╚═╝      ╚═╝   ╚═╝╚══════╝╚══════╝
--                                                                                          

-- ══════════════════════════════════════════════════════════════════════════════════════

fx_version 'cerulean'
game 'gta5'

author 'Filthy Lytiez'
name 'fl_utils'
description 'Filthy_Lytiez - Carry, Hostage, Cruise Control'
version '2.0.0'

shared_scripts {
    '@ox_lib/init.lua',
    '@qbx_core/modules/lib.lua',
}

client_scripts {
    '@qbx_core/modules/playerdata.lua',
    'client/main.lua',
}

server_script 'server/main.lua'

files {
    'config.lua'
}


server_exports {
    'GetCarryingData',
    'GetHostageData', 
    'IsPlayerCarrying',
    'IsPlayerCarried',
    'IsPlayerTakingHostage',
    'IsPlayerHostage'
}

lua54 'yes'
use_experimental_fxv2_oal 'yes'