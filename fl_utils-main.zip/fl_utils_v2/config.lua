return {
    debug = false,
    
    -- Carry System Configuration
    carry = {
        enabled = true,
        commandName = "carry",
        keyBind = "Y",
        interactionDistance = 3.0,
        animations = {
            carrier = {
                dict = "missfinale_c2mcs_1",
                anim = "fin_c2_mcs_1_camman",
                flag = 49
            },
            carried = {
                dict = "nm",
                anim = "firemans_carry",
                flag = 33,
                attachX = 0.27,
                attachY = 0.15,
                attachZ = 0.63
            }
        }
    },
    
    -- Cruise Control Configuration
    cruiseControl = {
        enabled = true,
        commandName = "cruisecontrol",
        keyBind = "F9",
        speedSet = 420, -- km/h for auto-enable
        checkInterval = 500, -- ms
        maxSpeed = 999.0 -- Reset value
    },
    
    -- Hostage System Configuration
    hostage = {
        enabled = true,
        commandName = "takehostage",
        keyBind = "F10",
        interactionDistance = 3.0,
        cooldown = 5, -- seconds
        maxDistance = 5.0, -- max distance before auto-release
        controls = {
            release = "E",
            kill = "U"
        },
        weapons = {
            "WEAPON_PISTOL",
            "WEAPON_COMBATPISTOL",
            "WEAPON_PISTOL50",
            "WEAPON_SNSPISTOL",
            "WEAPON_HEAVYPISTOL",
            "WEAPON_VINTAGEPISTOL",
            "WEAPON_MARKSMANPISTOL",
            "WEAPON_REVOLVER",
            "WEAPON_APPISTOL",
            "WEAPON_STUNGUN",
            "WEAPON_FLAREGUN",
            "WEAPON_DOUBLEACTION",
            "WEAPON_MICROSMG",
            "WEAPON_SMG",
            "WEAPON_ASSAULTSMG",
            "WEAPON_COMBATPDW",
            "WEAPON_MACHINEPISTOL",
            "WEAPON_MINISMG",
            "WEAPON_ASSAULTRIFLE",
            "WEAPON_CARBINERIFLE",
            "WEAPON_ADVANCEDRIFLE",
            "WEAPON_SPECIALCARBINE",
            "WEAPON_BULLPUPRIFLE",
            "WEAPON_COMPACTRIFLE",
            "WEAPON_MG",
            "WEAPON_COMBATMG",
            "WEAPON_GUSENBERG",
            "WEAPON_SNIPERRIFLE",
            "WEAPON_HEAVYSNIPER",
            "WEAPON_MARKSMANRIFLE",
            "WEAPON_PUMPSHOTGUN",
            "WEAPON_SAWNOFFSHOTGUN",
            "WEAPON_ASSAULTSHOTGUN",
            "WEAPON_BULLPUPSHOTGUN",
            "WEAPON_MUSKET",
            "WEAPON_HEAVYSHOTGUN",
            "WEAPON_DBSHOTGUN",
            "WEAPON_AUTOSHOTGUN"
        },
        animations = {
            taker = {
                dict = "anim@gangops@hostage@",
                anim = "perp_idle",
                flag = 49
            },
            victim = {
                dict = "anim@gangops@hostage@",
                anim = "victim_idle",
                flag = 49
            }
        }
    },
    
    -- Control code mappings
    controlCodes = {
        ['E'] = 38,
        ['U'] = 303,
        ['G'] = 47,
        ['Y'] = 246,
        ['F9'] = 56
    },
    
    -- Notification settings
    notifications = {
       position = 'top',
       duration = 3500,

       -- Carry notifications
       carryStarted = "Awu jita! Youre now carrying this laaitie",
       carryStopped = "Sharp, you dropped them off like hot pap",
       carryNoTarget = "No one close, bru. Where you grabbing air?",
       beingCarried = "Ey wena! Someone's busy taxi'ing you around",

      -- Cruise control notifications
       cruiseEnabled = "Cruise control ON at %d km/h — now you chillin'",
       cruiseDisabled = "Cruise OFF — foot down, we flying!",
    
       -- Hostage notifications
       hostageNoTarget = "There's no one to chapa, chief",
       hostageDeadTarget = "That ones already chilling with ancestors",
       hostageInVehicle = "Haibo! You cant jack someone in a car, mfethu",
       hostageNoWeapon = "You need a strap before you play gangster",
       hostageCooldown = "Yoh relax! You just did that. Wait a bit",
       hostageTaken = "You got a hostage now — dont mess it up!",
       hostageReleased = "You let them go... lucky fish",
       hostageKilled = "Jerr! You just dropped that one like its hot",
       beingHostage = "Awu! Someone got you — dont panic, chomi!",
       releasedFromHostage = "You free like taxi on Sunday",
       executedByCaptor = "Your captor moered you — shame bru",
       hostageControls = "Press %s to let go, %s to finish them off",
       hostageTooFar = "You wandered too far, hostage drama over",
       hostageDied = "You died — the whole stunt flopped"
    }
}